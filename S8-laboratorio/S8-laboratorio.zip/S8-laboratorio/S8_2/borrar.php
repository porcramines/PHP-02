<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Lee directorio</title>
<?php
if(isset($_GET["a"])){
	$foto= $_GET["a"];
	print "¿Seguro que desea borrar el archivo".$foto."?<br>";
	print "Una vez borrado no se podrá recuperar<br>";
	print "<img src='dioses/".$foto."'width='200px' height='200px'>";
	print "<a href='elimina.php?a=".$foto."'>Si</a>&nbsp;<a href='tabla.php'>No</a>";
}
?>
</head>
<body>
</body>
</html>